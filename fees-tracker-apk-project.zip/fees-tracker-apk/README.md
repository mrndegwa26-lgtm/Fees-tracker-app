# Fees Tracker: offline Android APK

The app is bundled inside the APK (www/index.html), so it works with no internet.

## Option A: build in the cloud (nothing to install)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (including the hidden .github folder) to the repository's main branch.
3. Open the Actions tab > Build APK > wait about 5 minutes.
4. Open the finished run, download the fees-tracker-apk artifact, unzip it, and you have app-debug.apk.

## Option B: build on your computer
Install Node 18+, Java 17 and Android Studio, then run:

    npm install
    npx cap add android
    npx cap sync android
    cd android && ./gradlew assembleDebug

The APK is at android/app/build/outputs/apk/debug/app-debug.apk.

## Install on a phone
Copy the APK to the phone, open it, and allow "install unknown apps" when asked.

## Notes
- Data is stored inside the app on that phone. Use Backup / Restore to move it. Backup and CSV open the Android share sheet.
- This is a debug build, fine for personal use. Play Store needs a signed release build and a custom icon (@capacitor/assets).
- To change the app, edit www/index.html and rebuild.
